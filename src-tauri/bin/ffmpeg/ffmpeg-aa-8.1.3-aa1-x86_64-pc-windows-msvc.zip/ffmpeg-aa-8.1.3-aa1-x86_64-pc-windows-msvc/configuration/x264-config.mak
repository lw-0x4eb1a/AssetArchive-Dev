SRCPATH=../src/x264
prefix=/Users/wzh/sourcecode/ffmpeg_aa_dedicated/build/x86_64-pc-windows-msvc/prefix
exec_prefix=${prefix}
bindir=${exec_prefix}/bin
libdir=${exec_prefix}/lib
includedir=${prefix}/include
SYS_ARCH=X86_64
SYS=WINDOWS
CC=x86_64-w64-mingw32-gcc
CFLAGS=-Wno-maybe-uninitialized -Wshadow -O3 -ffast-math -m64  -Wall -I. -I$(SRCPATH) -Os -D_WIN32_WINNT=0x0601 -D_POSIX_C_SOURCE=200112L -std=gnu99 -D_GNU_SOURCE -fomit-frame-pointer -fno-tree-vectorize -fvisibility=hidden
CFLAGSSO=
CFLAGSCLI=
COMPILER=GNU
COMPILER_STYLE=GNU
DEPMM=-MM -g0
DEPMT=-MT
LD=x86_64-w64-mingw32-gcc -o 
LDFLAGS=-m64  -static -static-libgcc  -Wl,--high-entropy-va -Wl,--dynamicbase,--nxcompat,--tsaware
LDFLAGSCLI= -lshell32 -Wl,--image-base,0x140000000
LIBX264=libx264.a
CLI_LIBX264=$(LIBX264)
AR=x86_64-w64-mingw32-ar rc 
RANLIB=x86_64-w64-mingw32-ranlib
STRIP=x86_64-w64-mingw32-strip
INSTALL=install
AS=nasm
ASFLAGS= -I. -I$(SRCPATH) -DARCH_X86_64=1 -I$(SRCPATH)/common/x86/ -f win64 -DSTACK_ALIGNMENT=16 -DPIC
RC=x86_64-w64-mingw32-windres
RCFLAGS=--target=pe-x86-64  -I. -o 
EXE=.exe
HAVE_GETOPT_LONG=1
DEVNULL=NUL
PROF_GEN_CC=-fprofile-generate
PROF_GEN_LD=-fprofile-generate
PROF_USE_CC=-fprofile-use
PROF_USE_LD=-fprofile-use
HAVE_OPENCL=no
CC_O=-o $@
default: lib-static
install: install-lib-static
